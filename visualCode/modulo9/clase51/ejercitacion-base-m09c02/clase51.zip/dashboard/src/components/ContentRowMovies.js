// título: de tipo string y obligatorio.
// - color de borde: de tipo string y obligatorio.
// - cifra: de tipo string o de tipo number y obligatorio.
// - ícono: una de las siguientes tres opciones: border-left-primary, border-left-success
// o border-left-warning; y obligatorio.

import React from 'react'
// import PropTypes from 'prop-types'

const ContentRowMovies = (props) => {

    let data = [
        {
            titulo:'movies data base',
            borderColor: 'primary',
            cifra: '21',
            icono: 'border-left-primary'
    }, 
        {
            titulo:'total awards',
            borderColor:'success',
            cifra: '21',
            icono:'border-left-success'
    }, 
        {
            titulo:'actors quantity',
            borderColor:'warning',
            cifra: '21',
            icono: 'border-left-warning'
    }]

  return (
    <div>
        {
            data.map((card, i) => {
                return(
                /*<!-- Movies in Data Base -->*/
						<div className="col-md-4 mb-4">
                        <div className={`card border-left-${card.borderColor} shadow h-100 py-2`}>
                            <div className="card-body">
                                <div className="row no-gutters align-items-center">
                                    <div className="col mr-2">
                                        <div className="text-xs font-weight-bold text-primary text-uppercase mb-1">Movies in Data Base</div>
                                        <div className="h5 mb-0 font-weight-bold text-gray-800">21</div>
                                    </div>
                                    <div className="col-auto">
                                        <i className="fas fa-film fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )
            })
        }
    </div>
  )

}

// ContentRowMovies.propTypes = {}

export default ContentRowMovies